package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "routine_tasks")
data class RoutineTask(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val category: String, // e.g. "Morning", "Work", "Evening", "Health"
    val time: String,     // e.g. "08:00 AM", "02:30 PM", "Anytime"
    val isCompleted: Boolean = false,
    val isVoiceCreated: Boolean = false,
    val aiSuggestedTips: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)
