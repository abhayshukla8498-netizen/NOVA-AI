package com.example.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface RoutineTaskDao {
    @Query("SELECT * FROM routine_tasks ORDER BY createdAt DESC")
    fun getAllTasks(): Flow<List<RoutineTask>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTask(task: RoutineTask): Long

    @Update
    suspend fun updateTask(task: RoutineTask)

    @Delete
    suspend fun deleteTask(task: RoutineTask)

    @Query("DELETE FROM routine_tasks WHERE isCompleted = 1")
    suspend fun clearCompletedTasks()

    @Query("SELECT * FROM routine_tasks WHERE id = :id LIMIT 1")
    suspend fun getTaskById(id: Long): RoutineTask?
}
