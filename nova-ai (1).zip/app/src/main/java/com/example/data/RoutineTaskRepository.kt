package com.example.data

import kotlinx.coroutines.flow.Flow

class RoutineTaskRepository(private val routineTaskDao: RoutineTaskDao) {
    val allTasks: Flow<List<RoutineTask>> = routineTaskDao.getAllTasks()

    suspend fun insertTask(task: RoutineTask): Long {
        return routineTaskDao.insertTask(task)
    }

    suspend fun updateTask(task: RoutineTask) {
        routineTaskDao.updateTask(task)
    }

    suspend fun deleteTask(task: RoutineTask) {
        routineTaskDao.deleteTask(task)
    }

    suspend fun clearCompletedTasks() {
        routineTaskDao.clearCompletedTasks()
    }

    suspend fun getTaskById(id: Long): RoutineTask? {
        return routineTaskDao.getTaskById(id)
    }
}
