package com.example.ui

import java.util.UUID

enum class Sender {
    USER, NOVA
}

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val sender: Sender,
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isSystemNotification: Boolean = false
)
