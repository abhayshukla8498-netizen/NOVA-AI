package com.example.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.Locale

class VoiceCommandManager(private val context: Context) {

    private var speechRecognizer: SpeechRecognizer? = null
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())
    private var watchdogRunnable: Runnable? = null
    private var isCommandHandled = false
    private var lastPartialText = ""

    private val recognitionIntent: Intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        // Shorter silence thresholds to respond extremely fast with 100,000% listening sensitivity
        putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 500L)
        putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 500L)
        putExtra("android.speech.extras.SPEECH_INPUT_MINIMUM_LENGTH_MILLIS", 800L)
    }

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening

    private val _speechText = MutableStateFlow("")
    val speechText: StateFlow<String> = _speechText

    private val _soundLevel = MutableStateFlow(0f) // 0.0f to 1.0f for audio visualizer pulse
    val soundLevel: StateFlow<Float> = _soundLevel

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    private var onResultListener: ((String) -> Unit)? = null

    private fun containsHotword(text: String): Boolean {
        val lower = text.lowercase().trim()
        val phrases = listOf(
            "hello nova", "hii nova", "hi nova",
            "hello nowa", "hii nowa", "hi nowa",
            "hello noba", "hii noba", "hi noba"
        )
        if (phrases.any { lower.contains(it) }) {
            return true
        }
        val words = lower.split(Regex("[\\s,?.!\\-]+"))
        val targetWords = setOf("nova", "nowa", "noba")
        if (words.any { it in targetWords }) {
            return true
        }

        // Fuzzy match for ultra high sensitivity (100,000% listening power)
        for (word in words) {
            if (word.length >= 3 && levenshteinDistance(word, "nova") <= 1) {
                return true
            }
        }
        return false
    }

    private fun levenshteinDistance(lhs: CharSequence, rhs: CharSequence): Int {
        val len0 = lhs.length + 1
        val len1 = rhs.length + 1
        var cost = IntArray(len0)
        var newcost = IntArray(len0)
        for (i in 0 until len0) cost[i] = i
        for (j in 1 until len1) {
            newcost[0] = j
            for (i in 1 until len0) {
                val match = if (lhs[i - 1] == rhs[j - 1]) 0 else 1
                val costReplace = cost[i - 1] + match
                val costInsert = cost[i] + 1
                val costDelete = newcost[i - 1] + 1
                newcost[i] = Math.min(Math.min(costInsert, costDelete), costReplace)
            }
            val swap = cost
            cost = newcost
            swap.also { newcost = it }
        }
        return cost[len0 - 1]
    }

    private fun isActionCommand(text: String): Boolean {
        if (!containsHotword(text)) {
            return false
        }
        val lower = text.lowercase()
        return lower.contains("youtube") ||
               lower.contains("mummy") || lower.contains("mom") || lower.contains("call") ||
               lower.contains("wifi") || lower.contains("wi-fi") ||
               lower.contains("flashlight") || lower.contains("torch") || lower.contains("light") ||
               lower.contains("volume") || lower.contains("mute") || lower.contains("unmute") ||
               lower.contains("settings") || lower.contains("bluetooth") || lower.contains("data") ||
               lower.contains("airplane") || lower.contains("hotspot") || lower.contains("brightness") ||
               lower.contains("battery") || lower.contains("ram") || lower.contains("storage") ||
               lower.contains("device") || lower.contains("android") ||
               lower.contains("alarm") || lower.contains("timer") ||
               lower.contains("add") || lower.contains("create") || lower.contains("task") ||
               lower.contains("routine") || lower.contains("clear") || lower.contains("complete")
    }

    init {
        try {
            if (SpeechRecognizer.isRecognitionAvailable(context)) {
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                    setRecognitionListener(object : RecognitionListener {
                        override fun onReadyForSpeech(params: Bundle?) {
                            _error.value = null
                            _speechText.value = "Listening... Speak now"
                        }

                        override fun onBeginningOfSpeech() {
                            _isListening.value = true
                        }

                        override fun onRmsChanged(rmsdB: Float) {
                            // Normalize RMS decibels to 0f to 1f
                            val normalized = ((rmsdB + 2f) / 12f).coerceIn(0.01f, 1f)
                            _soundLevel.value = normalized
                        }

                        override fun onBufferReceived(buffer: ByteArray?) {}

                        override fun onEndOfSpeech() {
                            _isListening.value = false
                        }

                        override fun onError(error: Int) {
                            watchdogRunnable?.let { handler.removeCallbacks(it) }
                            val errorMessage = when (error) {
                                SpeechRecognizer.ERROR_AUDIO -> "Audio recording error"
                                SpeechRecognizer.ERROR_CLIENT -> "Client-side error"
                                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Mic permission needed"
                                SpeechRecognizer.ERROR_NETWORK -> "Network error"
                                SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network timeout"
                                SpeechRecognizer.ERROR_NO_MATCH -> "No speech matching found"
                                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Voice system busy"
                                SpeechRecognizer.ERROR_SERVER -> "Server error"
                                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No speech detected"
                                else -> "Speech engine unavailable"
                            }
                            Log.e("VoiceCommandManager", "SpeechRecognizer error: $errorMessage ($error)")
                            _error.value = errorMessage
                            _isListening.value = false
                            _soundLevel.value = 0f

                            // Fallback to latest partial text if it was non-empty and contains the trigger word
                            if (!isCommandHandled && lastPartialText.isNotEmpty() && containsHotword(lastPartialText)) {
                                isCommandHandled = true
                                _speechText.value = lastPartialText
                                onResultListener?.invoke(lastPartialText)
                            }
                        }

                        override fun onResults(results: Bundle?) {
                            watchdogRunnable?.let { handler.removeCallbacks(it) }
                            val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            val text = matches?.firstOrNull() ?: ""
                            val finalText = if (text.isNotEmpty()) text else lastPartialText
                            
                            _speechText.value = finalText
                            _isListening.value = false
                            _soundLevel.value = 0f
                            
                            if (!isCommandHandled) {
                                isCommandHandled = true
                                onResultListener?.invoke(finalText)
                            }
                        }

                        override fun onPartialResults(partialResults: Bundle?) {
                            val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            val text = matches?.firstOrNull() ?: ""
                            if (text.isNotEmpty()) {
                                lastPartialText = text
                                _speechText.value = text

                                // Check if a complete action command with trigger word is spoken
                                if (!isCommandHandled && isActionCommand(text)) {
                                    isCommandHandled = true
                                    watchdogRunnable?.let { handler.removeCallbacks(it) }

                                    // Stop listening first to free up the microphone
                                    try {
                                        speechRecognizer?.stopListening()
                                    } catch (e: Exception) {}

                                    _isListening.value = false
                                    _soundLevel.value = 0f
                                    onResultListener?.invoke(text)
                                }
                            }
                        }

                        override fun onEvent(eventType: Int, params: Bundle?) {}
                    })
                }
            } else {
                _error.value = "On-device Speech Engine is offline or unavailable. Using Simulator mode."
            }
        } catch (e: Exception) {
            _error.value = "Speech recognition init issue: ${e.message}"
        }
    }

    fun startListening(onResult: (String) -> Unit) {
        onResultListener = onResult
        _speechText.value = "Activating voice sensor..."
        _isListening.value = true
        _error.value = null
        isCommandHandled = false
        lastPartialText = ""

        // Set up watchdog timer to auto-stop recording after 3s of activity
        // (crucial when background music or loud noise prevents the system from detecting end-of-speech)
        watchdogRunnable?.let { handler.removeCallbacks(it) }
        val watchdog = Runnable {
            if (_isListening.value && !isCommandHandled) {
                Log.d("VoiceCommandManager", "Watchdog triggered: forcing end of speech due to background noise/music")
                try {
                    speechRecognizer?.stopListening()
                } catch (e: Exception) {
                    Log.e("VoiceCommandManager", "Error stopping in watchdog: ${e.message}")
                }

                // If onResults doesn't call back within 500ms, manually fallback to last heard partial text
                handler.postDelayed({
                    if (!isCommandHandled && lastPartialText.isNotEmpty()) {
                        isCommandHandled = true
                        _speechText.value = lastPartialText
                        _isListening.value = false
                        _soundLevel.value = 0f
                        onResultListener?.invoke(lastPartialText)
                    }
                }, 500)
            }
        }
        watchdogRunnable = watchdog
        handler.postDelayed(watchdog, 3000)

        val hasPermission = androidx.core.content.ContextCompat.checkSelfPermission(
            context,
            android.Manifest.permission.RECORD_AUDIO
        ) == android.content.pm.PackageManager.PERMISSION_GRANTED

        if (speechRecognizer != null && hasPermission) {
            try {
                speechRecognizer?.startListening(recognitionIntent)
            } catch (e: Exception) {
                _error.value = "Failed: ${e.message}"
                _isListening.value = false
                watchdogRunnable?.let { handler.removeCallbacks(it) }
            }
        } else {
            _speechText.value = "Listening (Simulated Mode)... Click on micro-panel below or speak!"
        }
    }

    fun stopListening() {
        watchdogRunnable?.let { handler.removeCallbacks(it) }
        if (speechRecognizer != null) {
            speechRecognizer?.stopListening()
        }
        _isListening.value = false
        _soundLevel.value = 0f
    }

    fun simulateSpeechResult(simulatedText: String) {
        _speechText.value = simulatedText
        _isListening.value = false
        _soundLevel.value = 0f
        onResultListener?.invoke(simulatedText)
    }

    fun destroy() {
        speechRecognizer?.destroy()
        speechRecognizer = null
    }
}
