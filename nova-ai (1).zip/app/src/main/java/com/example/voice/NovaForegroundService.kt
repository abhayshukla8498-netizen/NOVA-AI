package com.example.voice

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.util.Log
import android.widget.Toast
import androidx.core.app.NotificationCompat
import java.util.Locale

class NovaForegroundService : Service(), TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private var isTtsReady = false
    private var speechRecognizer: SpeechRecognizer? = null
    private var isListening = false

    private val handler = android.os.Handler(android.os.Looper.getMainLooper())
    private var watchdogRunnable: Runnable? = null
    private var isCommandHandled = false
    private var lastPartialText = ""
    private var consecutiveErrorCount = 0
    private var isAppInForeground = false
    private var isVoiceManagerListening = false

    private fun hasWakeTrigger(text: String): Boolean {
        val lower = text.lowercase().trim()
        val phrases = listOf(
            "hello nova", "hii nova", "hi nova",
            "hello nowa", "hii nowa", "hi nowa",
            "hello noba", "hii noba", "hi noba"
        )
        
        // Check for explicit phrase matches first
        if (phrases.any { lower.contains(it) }) {
            return true
        }
        
        // Split by word boundaries and check for exact word match
        val words = lower.split(Regex("[\\s,?.!\\-]+"))
        val targetWords = setOf("nova", "nowa", "noba")
        if (words.any { it in targetWords }) {
            return true
        }

        // Fuzzy match for ultra high sensitivity (100,000% listening power)
        for (word in words) {
            if (word.length >= 3 && levenshteinDistance(word, "nova") <= 1) {
                return true
            }
        }
        return false
    }

    private fun levenshteinDistance(lhs: CharSequence, rhs: CharSequence): Int {
        val len0 = lhs.length + 1
        val len1 = rhs.length + 1
        var cost = IntArray(len0)
        var newcost = IntArray(len0)
        for (i in 0 until len0) cost[i] = i
        for (j in 1 until len1) {
            newcost[0] = j
            for (i in 1 until len0) {
                val match = if (lhs[i - 1] == rhs[j - 1]) 0 else 1
                val costReplace = cost[i - 1] + match
                val costInsert = cost[i] + 1
                val costDelete = newcost[i - 1] + 1
                newcost[i] = Math.min(Math.min(costInsert, costDelete), costReplace)
            }
            val swap = cost
            cost = newcost
            swap.also { newcost = it }
        }
        return cost[len0 - 1]
    }

    private fun isActionCommand(text: String): Boolean {
        val lower = text.lowercase()
        if (!hasWakeTrigger(lower)) {
            return false
        }
        return lower.contains("youtube") ||
               lower.contains("mummy") || lower.contains("mom") || lower.contains("call") ||
               lower.contains("wifi") || lower.contains("wi-fi") ||
               lower.contains("flashlight") || lower.contains("torch") || lower.contains("light") ||
               lower.contains("volume") || lower.contains("mute") || lower.contains("unmute") ||
               lower.contains("settings") || lower.contains("bluetooth") || lower.contains("data") ||
               lower.contains("airplane") || lower.contains("hotspot") || lower.contains("brightness") ||
               lower.contains("battery") || lower.contains("ram") || lower.contains("storage") ||
               lower.contains("device") || lower.contains("android") ||
               lower.contains("alarm") || lower.contains("timer") ||
               lower.contains("add") || lower.contains("create") || lower.contains("task") ||
               lower.contains("routine") || lower.contains("clear") || lower.contains("complete")
    }

    override fun onCreate() {
        super.onCreate()
        tts = TextToSpeech(this, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isTtsReady = true
            val prefs = getSharedPreferences("nova_settings", Context.MODE_PRIVATE)
            val selectedVoiceIndex = prefs.getInt("selected_voice_index", 0)
            setVoiceProfile(selectedVoiceIndex)
        } else {
            Log.e("NovaService", "TTS Initialization failed")
        }
    }

    private fun setVoiceProfile(index: Int) {
        val ttsEngine = tts ?: return
        val locales = listOf(
            Locale.US, Locale.UK, Locale.UK, Locale.US, Locale.CANADA,
            Locale.US, Locale.US, Locale.UK, Locale.US, Locale.CANADA
        )
        val pitches = listOf(1.25f, 0.9f, 1.15f, 0.85f, 1.3f, 1.0f, 1.1f, 0.78f, 1.35f, 0.95f)
        val rates = listOf(1.05f, 0.95f, 1.0f, 1.0f, 1.1f, 1.05f, 0.95f, 0.98f, 1.15f, 1.0f)
        val genders = listOf("Girl", "Boy", "Girl", "Boy", "Girl", "Boy", "Girl", "Boy", "Girl", "Boy")

        val targetLocale = locales.getOrElse(index) { Locale.US }
        val pitch = pitches.getOrElse(index) { 1.0f }
        val rate = rates.getOrElse(index) { 1.0f }
        val gender = genders.getOrElse(index) { "Girl" }

        try {
            ttsEngine.setPitch(pitch)
            ttsEngine.setSpeechRate(rate)
            ttsEngine.language = targetLocale

            val systemVoices = ttsEngine.voices
            if (systemVoices != null && systemVoices.isNotEmpty()) {
                val matchedVoice = systemVoices.filter { voice ->
                    voice.locale.language.equals(targetLocale.language, ignoreCase = true) &&
                    (targetLocale.country.isEmpty() || voice.locale.country.equals(targetLocale.country, ignoreCase = true))
                }.find { voice ->
                    val voiceName = voice.name.lowercase()
                    if (gender == "Girl") {
                        voiceName.contains("female") || voiceName.contains("fem") || 
                        voiceName.contains("-f-") || voiceName.contains("_f_") || 
                        voiceName.contains("girl") || voiceName.contains("soft")
                    } else {
                        voiceName.contains("male") || voiceName.contains("masc") || 
                        voiceName.contains("-m-") || voiceName.contains("_m_") || 
                        voiceName.contains("boy") || voiceName.contains("guy") || voiceName.contains("deep")
                    }
                } ?: systemVoices.find { voice ->
                    voice.locale.language.equals(targetLocale.language, ignoreCase = true)
                }
                if (matchedVoice != null) {
                    ttsEngine.voice = matchedVoice
                }
            }
        } catch (e: Exception) {
            Log.e("NovaService", "Error setting voice profile: ${e.message}")
        }
    }

    private fun adjustGenderPhrases(text: String, gender: String): String {
        var result = text
        if (gender == "Girl") {
            result = result.replace("raha hu", "rahi hu")
            result = result.replace("raha hoon", "rahi hoon")
            result = result.replace("raha", "rahi")
            result = result.replace("karta hu", "karti hu")
            result = result.replace("karta hoon", "karti hoon")
            result = result.replace("karta", "karti")
            result = result.replace("karunga", "karungi")
            result = result.replace("bataunga", "bataungi")
            result = result.replace("kar raha", "kar rahi")
            result = result.replace("kar raha hu", "kar rahi hu")
            result = result.replace("kar raha hoon", "kar rahi hoon")
            result = result.replace("karne ja raha", "karne ja rahi")
            result = result.replace("karta", "karti")
            result = result.replace("karta hu", "karti hu")
        } else {
            result = result.replace("rahi hu", "raha hu")
            result = result.replace("rahi hoon", "raha hoon")
            result = result.replace("rahi", "raha")
            result = result.replace("karti hu", "karta hu")
            result = result.replace("karti hoon", "karta hoon")
            result = result.replace("karti", "karta")
            result = result.replace("karungi", "karunga")
            result = result.replace("bataungi", "bataunga")
            result = result.replace("kar rahi", "kar raha")
            result = result.replace("kar rahi hu", "kar raha hu")
            result = result.replace("kar rahi hoon", "kar raha hoon")
            result = result.replace("karne ja rahi", "karne ja raha")
            result = result.replace("karti", "karta")
            result = result.replace("karti hu", "karta hu")
        }
        return result
    }

    private fun speakText(text: String) {
        if (isTtsReady && tts != null) {
            val prefs = getSharedPreferences("nova_settings", Context.MODE_PRIVATE)
            val index = prefs.getInt("selected_voice_index", 0)
            setVoiceProfile(index)
            
            val genders = listOf("Girl", "Boy", "Girl", "Boy", "Girl", "Boy", "Girl", "Boy", "Girl", "Boy")
            val gender = genders.getOrElse(index) { "Girl" }
            val adjustedText = adjustGenderPhrases(text, gender)
            
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                tts?.speak(adjustedText, TextToSpeech.QUEUE_FLUSH, null, "NovaBgSpeak")
            } else {
                @Suppress("DEPRECATION")
                tts?.speak(adjustedText, TextToSpeech.QUEUE_FLUSH, null)
            }
        } else {
            Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
        }
    }

    private fun showForegroundNotification() {
        val channelId = "nova_ai_background_service"
        val channelName = "Nova Background Assistant"
        val notificationId = 10102

        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                channelName,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Nova voice companion running in background"
                setShowBadge(true)
            }
            notificationManager.createNotificationChannel(channel)
        }

        // Tap to Speak PendingIntent
        val speakIntent = Intent(this, NovaForegroundService::class.java).apply {
            action = "com.example.voice.action.TAP_TO_SPEAK"
        }
        val speakPendingIntent = PendingIntent.getService(
            this, 1, speakIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Call Mummy PendingIntent
        val callMummyIntent = Intent(this, NovaForegroundService::class.java).apply {
            action = "com.example.voice.action.CALL_MUMMY"
        }
        val callMummyPendingIntent = PendingIntent.getService(
            this, 2, callMummyIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Open YouTube PendingIntent
        val openYoutubeIntent = Intent(this, NovaForegroundService::class.java).apply {
            action = "com.example.voice.action.OPEN_YOUTUBE"
        }
        val openYoutubePendingIntent = PendingIntent.getService(
            this, 3, openYoutubeIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Check Battery PendingIntent
        val batteryIntent = Intent(this, NovaForegroundService::class.java).apply {
            action = "com.example.voice.action.CHECK_BATTERY"
        }
        val batteryPendingIntent = PendingIntent.getService(
            this, 4, batteryIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Content Action Intent: brings main app forward
        val contentIntent = Intent(this, com.example.MainActivity::class.java)
        val contentPendingIntent = PendingIntent.getActivity(
            this, 0, contentIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(com.example.R.drawable.ic_launcher_foreground)
            .setContentTitle("NOVA AI: Voice Companion Active")
            .setContentText("Listening & ready in background. Speak or use actions.")
            .setSubText("Nova Background Core")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setOngoing(true)
            .setContentIntent(contentPendingIntent)
            .setColor(0xFF818CF8.toInt())
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .addAction(com.example.R.drawable.ic_launcher_foreground, "🎙️ Speak", speakPendingIntent)
            .addAction(com.example.R.drawable.ic_launcher_foreground, "📞 Mummy", callMummyPendingIntent)
            .addAction(com.example.R.drawable.ic_launcher_foreground, "📱 YouTube", openYoutubePendingIntent)
            .addAction(com.example.R.drawable.ic_launcher_foreground, "🔋 Battery", batteryPendingIntent)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val serviceType = android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            startForeground(notificationId, builder.build(), serviceType)
        } else {
            startForeground(notificationId, builder.build())
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        when (action) {
            "com.example.voice.action.START" -> {
                showForegroundNotification()
                speakText("Nova background voice core activated. Ready for your commands, Sir!")
                isAppInForeground = false // Set to false initially, let APP_RESUMED handle start
                consecutiveErrorCount = 0
            }
            "com.example.voice.action.APP_RESUMED" -> {
                isAppInForeground = true
                consecutiveErrorCount = 0
                startBackgroundSpeechRecognition()
            }
            "com.example.voice.action.APP_PAUSED" -> {
                isAppInForeground = false
                stopBackgroundSpeechRecognition()
            }
            "com.example.voice.action.PAUSE_LISTENING" -> {
                isVoiceManagerListening = true
                stopBackgroundSpeechRecognition()
            }
            "com.example.voice.action.RESUME_LISTENING" -> {
                isVoiceManagerListening = false
                if (isAppInForeground) {
                    consecutiveErrorCount = 0
                    startBackgroundSpeechRecognition()
                }
            }
            "com.example.voice.action.STOP" -> {
                speakText("Nova background systems offline. Goodbye, Sir.")
                stopBackgroundSpeechRecognition()
                stopSelf()
            }
            "com.example.voice.action.SPEAK" -> {
                val text = intent.getStringExtra("text") ?: ""
                speakText(text)
            }
            "com.example.voice.action.TAP_TO_SPEAK" -> {
                val launchIntent = Intent(this, com.example.MainActivity::class.java)
                launchIntent.action = "com.example.voice.intent.START_VOICE"
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                startActivity(launchIntent)
            }
            "com.example.voice.action.CALL_MUMMY" -> {
                speakText("Ok Sir, mummy ko call kar rahi hu.")
                val dialIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:9876543210")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                try {
                    startActivity(dialIntent)
                } catch (e: Exception) {
                    Toast.makeText(this, "Dialer app not found", Toast.LENGTH_SHORT).show()
                }
            }
            "com.example.voice.action.OPEN_YOUTUBE" -> {
                speakText("Ok Sir, open kar raha hu.")
                val pm = packageManager
                var launchIntent = pm.getLaunchIntentForPackage("com.google.android.youtube")
                if (launchIntent == null) {
                    launchIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com")).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                } else {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                try {
                    startActivity(launchIntent)
                } catch (e: Exception) {
                    Toast.makeText(this, "Could not open YouTube", Toast.LENGTH_SHORT).show()
                }
            }
            "com.example.voice.action.CHECK_BATTERY" -> {
                val batteryManager = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
                val pct = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
                speakText("Sir, battery percentage is $pct percent.")
                Toast.makeText(this, "Battery: $pct%", Toast.LENGTH_LONG).show()
            }
        }
        return START_STICKY
    }

    private fun startBackgroundSpeechRecognition() {
        if (!isAppInForeground) {
            Log.d("NovaService", "App is not in foreground. Background speech recognition is paused to avoid AppOps/security errors.")
            return
        }
        if (isVoiceManagerListening) {
            Log.d("NovaService", "VoiceManager is active in the foreground app. Background speech recognition is paused to avoid conflicts.")
            return
        }
        if (androidx.core.content.ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            Log.e("NovaService", "RECORD_AUDIO permission not granted. Background listening paused.")
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Log.e("NovaService", "Background speech recognition is not available on this device")
            return
        }
        
        try {
            isCommandHandled = false
            lastPartialText = ""
            
            // Set up watchdog timer to auto-stop recording after 3 seconds
            // (essential for dealing with background noise, music, or video play)
            watchdogRunnable?.let { handler.removeCallbacks(it) }
            val watchdog = Runnable {
                if (isListening && !isCommandHandled) {
                    Log.d("NovaService", "Background Watchdog triggered: forcing end of speech due to noise")
                    try {
                        speechRecognizer?.stopListening()
                    } catch (e: Exception) {
                        Log.e("NovaService", "Error stopping background speech: ${e.message}")
                    }
                    
                    // Fallback to last heard partial text if nothing else resolves within 500ms
                    handler.postDelayed({
                        if (!isCommandHandled && lastPartialText.isNotEmpty()) {
                            isCommandHandled = true
                            isListening = false
                            handleBackgroundVoiceCommand(lastPartialText)
                            restartListeningDebounced()
                        }
                    }, 500)
                }
            }
            watchdogRunnable = watchdog
            handler.postDelayed(watchdog, 3000)

            if (speechRecognizer == null) {
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
            }
            val recognizer = speechRecognizer ?: return
            
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                // Shorter silence thresholds for 100,000% listening sensitivity
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 500L)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 500L)
                putExtra("android.speech.extras.SPEECH_INPUT_MINIMUM_LENGTH_MILLIS", 800L)
            }
            
            recognizer.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {
                    isListening = true
                }
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {
                    isListening = false
                }
                override fun onError(error: Int) {
                    watchdogRunnable?.let { handler.removeCallbacks(it) }
                    isListening = false
                    consecutiveErrorCount++
                    Log.d("NovaService", "SpeechRecognizer onError: $error. Consecutive errors: $consecutiveErrorCount")
                    
                    // Fallback to latest partial text if it was non-empty and contains the trigger
                    if (!isCommandHandled && lastPartialText.isNotEmpty() && 
                        (lastPartialText.lowercase().contains("nova") || 
                         lastPartialText.lowercase().contains("nowa") || 
                         lastPartialText.lowercase().contains("noba"))) {
                        isCommandHandled = true
                        consecutiveErrorCount = 0
                        handleBackgroundVoiceCommand(lastPartialText)
                    }
                    restartListeningDebounced()
                }
                override fun onResults(results: Bundle?) {
                    watchdogRunnable?.let { handler.removeCallbacks(it) }
                    isListening = false
                    consecutiveErrorCount = 0
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val text = matches?.firstOrNull() ?: ""
                    val finalText = if (text.isNotEmpty()) text else lastPartialText
                    
                    if (!isCommandHandled) {
                        isCommandHandled = true
                        if (finalText.isNotEmpty()) {
                            handleBackgroundVoiceCommand(finalText)
                        }
                    }
                    restartListeningDebounced()
                }
                override fun onPartialResults(partialResults: Bundle?) {
                    val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val text = matches?.firstOrNull() ?: ""
                    if (text.isNotEmpty()) {
                        lastPartialText = text
                        consecutiveErrorCount = 0
                    }
                }
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            
            recognizer.startListening(intent)
            isListening = true
        } catch (e: Exception) {
            Log.e("NovaService", "Background speech engine start error: ${e.message}")
        }
    }

    private fun restartListeningDebounced() {
        watchdogRunnable?.let { handler.removeCallbacks(it) }
        if (!isAppInForeground || isVoiceManagerListening) {
            Log.d("NovaService", "App is not in foreground or VoiceManager is listening. Pausing auto-restart.")
            return
        }
        if (consecutiveErrorCount >= 10) {
            Log.w("NovaService", "Too many consecutive errors ($consecutiveErrorCount). Pausing background listening to prevent loops.")
            return
        }
        val delayMs = when {
            consecutiveErrorCount >= 5 -> 10000L  // 10 seconds back-off
            else -> 1500L                         // 1.5 seconds default
        }
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            if (!isListening && isAppInForeground && !isVoiceManagerListening) {
                startBackgroundSpeechRecognition()
            }
        }, delayMs)
    }

    private fun stopBackgroundSpeechRecognition() {
        watchdogRunnable?.let { handler.removeCallbacks(it) }
        try {
            speechRecognizer?.stopListening()
            speechRecognizer?.destroy()
            speechRecognizer = null
            isListening = false
        } catch (e: Exception) {
            Log.e("NovaService", "Error stopping background speech: ${e.message}")
        }
    }

    private fun handleBackgroundVoiceCommand(text: String) {
        val lower = text.lowercase().trim()
        Log.d("NovaService", "Background voice command received: $text")
        
        if (!hasWakeTrigger(lower)) {
            // SILENTLY IGNORE background noise/music/video talk!
            // No speaking or toast here, so background noise is completely ignored.
            return
        }
        
        when {
            lower.contains("open youtube") || (lower.contains("youtube") && lower.contains("open")) -> {
                speakText("Ok Sir, open kar raha hu.")
                val pm = packageManager
                var intent = pm.getLaunchIntentForPackage("com.google.android.youtube")
                if (intent == null) {
                    intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com"))
                }
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                try {
                    startActivity(intent)
                } catch (e: Exception) {
                    Log.e("NovaService", "Failed to start YouTube activity")
                }
            }
            lower.contains("call mummy") || (lower.contains("mummy") && lower.contains("call")) -> {
                speakText("Ok Sir, mummy ko call kar rahi hu.")
                val dialIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:9876543210")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                try {
                    startActivity(dialIntent)
                } catch (e: Exception) {
                    Log.e("NovaService", "Failed to start Dialer activity")
                }
            }
            lower.contains("wifi") || lower.contains("wi-fi") -> {
                speakText("Ok Sir, wifi on kar raha hu.")
                val wifiIntent = Intent(android.provider.Settings.ACTION_WIFI_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                try {
                    startActivity(wifiIntent)
                } catch (e: Exception) {
                    Log.e("NovaService", "Failed to start Wifi settings activity")
                }
            }
            lower.contains("battery") || lower.contains("battery percentage") || lower.contains("charge") -> {
                val batteryManager = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
                val pct = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
                speakText("Sir, battery percentage is $pct percent.")
            }
            lower.contains("who are you") || lower.contains("tum kaun ho") || lower.contains("about") -> {
                speakText("Sir, I am NOVA, your intelligent voice AI assistant designed to execute phone commands and routines.")
            }
            lower.contains("how are you") || lower.contains("kaise ho") -> {
                speakText("Sir, my virtual circuits are humming with energy! I am ready to assist you.")
            }
            lower.contains("date") || lower.contains("today") || lower.contains("tarikh") -> {
                val today = java.text.SimpleDateFormat("EEEE, MMMM dd, yyyy", Locale.getDefault()).format(java.util.Date())
                speakText("Sir, today is $today.")
            }
            lower.contains("time") || lower.contains("samay") || lower.contains("baje") -> {
                val time = java.text.SimpleDateFormat("hh:mm a", Locale.getDefault()).format(java.util.Date())
                speakText("Sir, current time is $time.")
            }
            else -> {
                // If they said the wake word but didn't specify any known background command, give a friendly reply
                speakText("Yes Sir! How can NOVA help you today?")
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        stopBackgroundSpeechRecognition()
        try {
            tts?.stop()
            tts?.shutdown()
            tts = null
        } catch (e: Exception) {
            Log.e("NovaService", "TTS Shutdown issues: ${e.message}")
        }
    }
}
